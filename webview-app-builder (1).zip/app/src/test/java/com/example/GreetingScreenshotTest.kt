package com.example

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.unit.dp
import com.example.data.model.WebAppItem
import com.example.ui.launcher.AppGridItem
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun app_icon_screenshot() {
    val sampleApp = WebAppItem(
      name = "WebView App",
      type = "WEB_URL",
      targetUrl = "https://example.com",
      iconPreset = "#3B82F6"
    )
    composeTestRule.setContent {
      MyApplicationTheme {
        AppGridItem(
          app = sampleApp,
          shape = RoundedCornerShape(16.dp),
          onClick = {},
          onLongClick = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/app_icon.png")
  }
}
